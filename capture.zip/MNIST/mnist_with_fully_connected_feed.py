from __future__ import absolute_import
from __future__ import division
from __future__ import print_function


import argparse
import os
import sys
import time

from six.moves import xrange
import tensorflow as tf

import read_data
